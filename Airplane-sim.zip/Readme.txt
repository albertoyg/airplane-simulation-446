To run: 
        python3 simulator.py

If you'd like to see the plane drawn, run the simulation with draw set to True on line 312
IMPORTANT NOTE: Set the num_sims to 1 if you are drawing the plane. 

You may change the total number of simulations at line 301
You may change the size of the aircraft by changing the values in the plane_size dictionary. Note the dictionary uses values (rows, cols) where cols only refer to the number of columns on one side of the aisle. 